#Password Beta Screen
import tkinter as tk
import time

#Global Variables
Password = "Password123"
tries = 1

#Functions
def Open_main():
    root = tk.Tk()
    root.geometry("500x500")
    root.title("Window")

    frame.destroy()

def On_clicked():
    Entered_txt = txtEnter.get()
    global Password
    if Entered_txt == Password:
        Open_main()

    else:
        global tries
        if tries == 3:
            frame.destroy()

        else:
            tries = tries + 1
            InvalidL.config(text="INCORRECT!")
            InvalidL.update()
            time.sleep(1.0)
            InvalidL.config(text="")

#Create Main window
frame = tk.Tk()
frame.geometry("600x150")
frame.title("Password")

#Window interactables
titleL = tk.Label(frame, text="ENTER PASSWORD", font="bold 15")
titleL.place(x=200, y=10, width=200, height=15)

InvalidL = tk.Label(frame, text="", font="bold 10", fg="red")
InvalidL.place(x=200, y=30, width=200, height=10)

txtEnter = tk.Entry(frame, font="bold 15")
txtEnter.place (x=200, y=50, width=200, height=30)

enterB = tk.Button(frame, text="LOG-IN", command=On_clicked)
enterB.place(x=250, y=100, width=100, height=25)

frame.mainloop()
